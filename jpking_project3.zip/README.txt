Jason King

Type "make" to compile, then "./p3" to run

I commented out my printdt() functions (inside the node update functions) so my trace would look similar to the given trace, so feel free to uncomment those if needed
